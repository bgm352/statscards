"""Statsline Core Arbitrage & Vision Engine."""
